#ifndef _INTERRUPT_HANDLER_ENTRY_H
#define _INTERRUPT_HANDLER_ENTRY_H

#ifndef ASM

void keyboard_entry();
void rtc_entry();
void pit_entry();
void mouse_entry();

#endif
#endif
