make clean
make dep
sudo make
gdb bootimg
# target remote 10.0.2.2:1234