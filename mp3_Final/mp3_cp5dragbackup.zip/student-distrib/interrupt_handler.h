#ifndef _INTERRUPT_HANDLER_H
#define _INTERRUPT_HANDLER_H

void INT_keyboard();
void INT_rtc();
void INT_pit();
void INT_mouse();

#endif
